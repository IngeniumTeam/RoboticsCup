#include <Arduino.h>

#include "Keybull.h"

Keybull::Keybull (int fromPin)
{
    char keys[4][3] = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 }, { 10, 11, 12 } };
    byte rowPins[4] = { fromPin + 5, 2, fromPin + 1, fromPin + 3 };
    byte colPins[3] = { fromPin + 4, fromPin + 6, fromPin + 2 };
    byte rows = 4;
    byte cols = 3;
    Keypad keypad(makeKeymap(keys), rowPins, colPins, rows, cols);
    keybull = &keypad;
}

/**
 * Function to call each loops of the program
 * 
 * @return int between 1 and `number of keyboard keys (cols*rows)` if one key is pressed or -1 if any key is pressed
 */
int Keybull::getValue()
{
    int key = keybull -> getKey();
    if (key)
    {
        return key;
    }
    else
    {
        return 0;
    }
}
