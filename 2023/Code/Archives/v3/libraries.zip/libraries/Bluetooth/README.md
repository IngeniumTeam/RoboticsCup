# Bluetooth

This is an ideal Arduino library for Bluetooth communication.

Everything you need to create a Bluetooth system and includes the ArduinoJson library by @bblanchon for Json encoded messages.