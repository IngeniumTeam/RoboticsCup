# Mecanum

This is a library to work a group of 4 motors equiped with mecanum wheels:

![Mecanum wheels deplacements](https://upload.wikimedia.org/wikipedia/commons/c/c4/Mecanum_wheel_control_principle.svg)

[Wikipedia article](https://en.wikipedia.org/wiki/Mecanum_wheel)
