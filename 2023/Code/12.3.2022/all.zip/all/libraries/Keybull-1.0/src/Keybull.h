#include <Arduino.h>
#include <Keypad.h>

class Keybull
{
    public:
        Keybull(int fromPin);
        int getValue();
        int key;
        Keypad *keybull;
};
