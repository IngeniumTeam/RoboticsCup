# Superbowl

This is the basket code from the Ingenium team.

The INO file depends of the following list of libraries:
- [Digit](https://github.com/IngeniumTeam/Digit)
- [PhotoElectric](https://github.com/IngeniumTeam/PhotoElectric)

The hardware consists of an Arduino Uno board [...]
