# Timino
This is an Arduino library for working with time without any hardware components
