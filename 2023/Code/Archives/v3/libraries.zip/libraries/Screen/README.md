# Clock
This is an Arduino library to draw time on a TFT screen
