# StepperMotor
This is an arduino library to help you control your stepper motor with non-blocking accelaration powerd by AccelStepper and limit switch setup
